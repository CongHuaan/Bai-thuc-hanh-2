/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai9th_2;

/**
 *
 * @author LENOVO
 */
public class Item {
    private String id,name;
    private int price, date;
    
    public Item(String id, String name, int price, int date) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.date = date;
    }
    
    public int getDate(){
        return this.date;
    }
    
    public String getId(){
        return this.id;
    }
    
    public int getPrice(){
        return this.price;
    }
}
