/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai9th_2;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

/**
 *
 * @author LENOVO
 */
public class Main {
    public static void main(String[] args) throws FileNotFoundException, ParseException {
        Scanner sc = new Scanner(new File("MUAHANG.in"));
        int t = Integer.parseInt(sc.nextLine());
        Item it[] = new Item[t];
        for(int i = 0; i < t; i++) {
            String id = sc.nextLine();
            String name = sc.nextLine();
            int price = Integer.parseInt(sc.nextLine());
            int date = Integer.parseInt(sc.nextLine());
            it[i] = new Item(id, name, price, date);
        }
        int n = Integer.parseInt(sc.nextLine());
        KhachHang kh[] = new KhachHang[n];
        for(int i = 0; i < n; i++) {
            String name = sc.nextLine();
            String adress = sc.nextLine();
            String id = sc.nextLine();
            int sl = Integer.parseInt(sc.nextLine());
            String day = sc.nextLine();
            kh[i] = new KhachHang(i, name, adress, id, sl, day);
        }
        for(int i = 0; i < n; i++) {
            for(int j = 0; j < t; j++) {
                if(kh[i].getId().equals(it[j].getId())) {
                    kh[i].setPay(it[j].getPrice());
                    kh[i].setDay(it[j].getDate());
                }
            }
        }
        Arrays.sort(kh, new Comparator<KhachHang>(
        ) {
            @Override
            public int compare(KhachHang o1, KhachHang o2) {
                if(o1.getNam() == o2.getNam()) {
                    if(o1.getThang() == o2.getThang()) {
                        if(o1.getNgay() == o2.getNgay()) {
                            return o1.getMa().compareTo(o2.getMa());
                        }
                        else{
                            if(o1.getNgay() < o2.getNgay()) return -1;
                        }
                        return 1;
                    }
                    else if(o1.getThang() < o2.getThang()) return -1;
                    return 1;
                }
                else if(o1.getNam() < o2.getNam()) return -1;
                return 1;
            }
        });
        for(int i = 0; i < n; i++) {
            System.out.println(kh[i]);
        }
    }
}
