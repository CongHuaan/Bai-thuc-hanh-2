/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai9th_2;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author LENOVO
 */
public class KhachHang {
    private String ma, name, adress, id, day;
    private int sl,pay;
    
    public KhachHang(int ma, String name, String adress, String id, int sl, String day) {
        this.ma = "KH" + String.format("%02d", ma + 1);
        this.name = name;
        this.adress = adress;
        this.id = id;
        this.sl = sl;
        this.day = day;
    } 
    
    public String getId(){
        return this.id;
    }
    
    public void setPay(int n){
        this.pay = this.sl * n;
    }
    
    public void setDay(int han) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            Date date = dateFormat.parse(this.day);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(Calendar.MONTH, han);
            Date newdate = calendar.getTime();
            String daynew = dateFormat.format(newdate);
            this.day = daynew;
    }
    
    public String getDay(){
        return this.day;
    }
    
    public int getNgay(){
        String a[] = this.day.split("/");
        return Integer.parseInt(a[0]);
    }
    public int getThang(){
        String a[] = this.day.split("/");
        return Integer.parseInt(a[1]);
    }
    public int getNam(){
        String a[] = this.day.split("/");
        return Integer.parseInt(a[2]);
    }
    
    public String getMa(){
        return this.ma;
    }
    
    @Override
    public String toString(){
        return this.ma + " " + this.name + " " + this.adress + " " + this.id + " " + this.pay + " " + this.day;
    }
    
}
