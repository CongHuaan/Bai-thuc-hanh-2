/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai10th_2;

/**
 *
 * @author LENOVO
 */
public class GiangVien {
    private String id, name;
    private double gio;
    
    public GiangVien(String s) {
        String a[] = s.split("\\s+");
        this.id = a[0];
        String word = "";
        for(int i = 1; i < a.length; i++) {
            word += a[i] + " ";
        }
        this.name = word.trim();
    }
    
    public String getId(){
        return this.id;
    }
    
    public void setGio(double x){
        this.gio += x;
    }
    
    @Override
    public String toString(){
        return String.format("%s %.2f", this.name, this.gio);
    }
}
