/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai10th_2;

import java.net.IDN;

/**
 *
 * @author LENOVO
 */
public class GioChuan {
    private String id, mon;
    private double gio;
    
    public GioChuan(String s) {
        String a[] = s.split("\\s+");
        this.id = a[0];
        this.mon = a[1];
        this.gio = Double.parseDouble(a[2]);
    }
    
    public double getGio(){
        return this.gio;
    }
    
    public String getId(){
        return this.id;
    }
}
