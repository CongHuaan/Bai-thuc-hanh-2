/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai10th_2;

/**
 *
 * @author LENOVO
 */
public class MonHoc {
    private String id, name;
    
    public MonHoc(String id, String name) {
        this.id = id;
        this.name = name;
    }
}
