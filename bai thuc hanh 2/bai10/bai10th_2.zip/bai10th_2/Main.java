/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai10th_2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author LENOVO
 */
public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("MONHOC.in"));
        int t = Integer.parseInt(sc.nextLine());
        for(int i = 0; i < t; i++) {
            sc.nextLine();
        }
        sc = new Scanner(new File("GIANGVIEN.in"));
        int n = Integer.parseInt(sc.nextLine());
        GiangVien gv[] = new GiangVien[n];
        for(int i = 0; i < n; i++) {
            gv[i] = new GiangVien(sc.nextLine());
        }
        sc = new Scanner(new File("GIOCHUAN.in"));
        int m = Integer.parseInt(sc.nextLine());
        GioChuan gc[] = new GioChuan[m];
        for(int i = 0; i < m; i++) {
            gc[i] = new GioChuan(sc.nextLine());
        }
        for(int i = 0; i < n; i++) {
            for(int j = 0; j < m; j++) {
                if(gv[i].getId().equals(gc[j].getId())) {
                    gv[i].setGio(gc[j].getGio());
                }
            }
        }
        for(int i = 0; i < n; i++) {
            System.out.println(gv[i]);
        }
    }
}
