/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai7th_2;

/**
 *
 * @author LENOVO
 */
public class SinhVien {
    private String id,name,lop,email,number;
    
    public SinhVien(String id, String name, String lop, String email, String number) {
        this.id = id;
        this.name = name;
        this.lop = lop;
        this.email = email;
        this.number = "0" + number;
    }
    
    public String getLop(){
        return this.lop;
    }
    
    public String getId(){
        return this.id;
    }
    
    @Override
    public String toString(){
        return this.id + " " + this.name + " " + this.lop + " " + this.email + " " + this.number;
    }
}
