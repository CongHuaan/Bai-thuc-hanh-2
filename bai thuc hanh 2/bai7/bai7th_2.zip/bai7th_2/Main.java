/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai7th_2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

/**
 *
 * @author LENOVO
 */
public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        ArrayList<SinhVien> sv = new ArrayList<>();
        Scanner sc = new Scanner(new File("DANHSACH.in"));
        while(sc.hasNext()) {
            String id = sc.nextLine();
            String name = sc.nextLine();
            String lop = sc.nextLine();
            String email = sc.nextLine();
            String number = sc.nextLine();
            sv.add(new SinhVien(id,name,lop,email,number));
        }
        Collections.sort(sv, new Comparator<SinhVien>(
        ) {
            @Override
            public int compare(SinhVien o1, SinhVien o2) {
                if(o1.getLop().compareTo(o2.getLop()) == 0) {
                    if(o1.getId().compareTo(o2.getId()) < 0) {
                        return -1;
                    }
                    return 1;
                }
                else {
                    if(o1.getLop().compareTo(o2.getLop()) < 0) {
                        return -1;
                    }
                    return 1;
                }
            }
        });
        for(SinhVien x : sv) {
            System.out.println(x);
        }
    }
}
