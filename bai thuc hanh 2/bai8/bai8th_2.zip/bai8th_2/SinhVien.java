/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai8th_2;

/**
 *
 * @author LENOVO
 */
public class SinhVien {
    private String id, name, lop, email, number, tenthay = "", mon;
    
    public SinhVien(String id, String name, String lop, String eamil, String number) {
        this.id = id;
        this.name = name;
        this.number = "0" + number;
    }
    
    public void setTenthay(String s){
        this.tenthay = s.trim();
    }
    
    public void setMon(String s){
        this.mon = s.trim();
    }
    
    public String getId(){
        return this.id;
    }
    
    public String getTenthay(){
        return this.tenthay;
    }
    
    @Override
    public String toString(){
        return this.id + " " + this.name + " " + this.tenthay + " " + this.mon + " " + this.number;
    }
}
