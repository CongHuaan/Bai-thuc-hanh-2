/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai8th_2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

/**
 *
 * @author LENOVO
 */
public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("E:\\bt Java\\baitap\\src\\DAYSO.in"));
        ArrayList<SinhVien> a = new ArrayList<>();
        ArrayList<GiangVien> b = new ArrayList<>();
        while(sc.hasNext()) {
            String id = sc.nextLine();
            String name = sc.nextLine();
            String lop = sc.nextLine();
            String email = sc.nextLine();
            String number = sc.nextLine();
            SinhVien tmp = new SinhVien(id, name, lop, email, number);
            a.add(tmp);
        }
        sc = new Scanner(new File("E:\\bt Java\\baitap\\src\\DN.in"));
        int t = Integer.parseInt(sc.nextLine());
        for(int i = 0; i < t; i++) {
            String s = sc.nextLine();
            String temp[] = s.split("\\s+");
            int n = Integer.parseInt(temp[temp.length-1]);
            String word = "";
            for(int j = 0; j < temp.length - 1; j++) {
                word += temp[j] + " ";
            }
            String name = word.trim();
            GiangVien gv[] = new GiangVien[n];
            for(int j = 0; j < n; j++) {
                b.add(new GiangVien(sc.nextLine(), name));
            }
        }
        for(GiangVien x : b) {
            for(SinhVien s : a) {
                if(x.getId().equals(s.getId())) {
                    s.setTenthay(x.getName());
                    s.setMon(x.getMon());
                }
            }
        }
        Collections.sort(a, new Comparator<SinhVien>(
        ) {
            @Override
            public int compare(SinhVien o1, SinhVien o2) {
                if(o1.getId().compareTo(o2.getId()) < 0) return -1;
                return 1;
            }
        });
        for(SinhVien x : a) {
            System.out.println(x);
        }
    }
}
